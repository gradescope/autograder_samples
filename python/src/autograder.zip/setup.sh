#!/usr/bin/env bash

apt-get install -y python python-pip python-dev

pip install subprocess32 gradescope-utils
