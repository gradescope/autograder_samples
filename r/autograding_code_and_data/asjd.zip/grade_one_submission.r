# load in the package
library(gradeR)

calcGradesForGradescope("assignment1.R",       # each student's submission must be named this!
                        "assignment1_tests.r") # the file with all of the testthat tests 
  
