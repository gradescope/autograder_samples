apt-get -y install openjdk-8-jdk maven bash
apt-get install --reinstall ca-certificates-java
update-ca-certificates -f
