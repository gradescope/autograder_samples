#! /bin./bash

apt-get update
apt-get install -qy nunit nunit-console monodevelop
